# Pass 5 execution record — native two-class work

Current status (2026-10-10): final two-class library c15e9f... passed full Linux
correctness and macOS targeted tests. The first partial fragbench matrix is archived
under remote results/pass5/prior/folded-wrappers: GCC folded distinct lifetime
wrappers to one debug identity. Server-sim now disables that folding and uses seeded
TTL draws to avoid sample-period aliasing. The new supervisor is
scripts/pass5-frag-finish.sh (PID 4044072, also in results/pass5/frag-finish.pid).
Workload validation passed. The repeated instrument is negative; its 30 timings
have zero inference overlaps. Fragbench has completed all four synthetic blocks and is collecting Redis Mesh
cold model decisions;
sensitivity and regression follow. No regression has started. Progress: results/pass5/stage.txt and
results/bench.log; exit: results/pass5/status. Do not replace the active build.
Old pass-4 text below is historical.

# Pass 4 execution record

Status (2026-10-10): acceptance has not passed; full model matrices are withheld.

Latest completed five-repetition check: cfrac none/mi time 1.023761, RSS
1.000914, key-only/none RSS 1.033790. That compare attempt was stopped and archived.
The subsequent cache diagnostic passed targeted Linux/macOS tests and reduced
cfrac live time substantially, but still missed key RSS and threaded live gates.
Current detached supervisor: **2101937**, `scripts/pass4.sh`; finalizer **2101938**.
It builds and runs targeted correctness, then five interleaved repetitions across
all 22 acceptance workloads. Progress: `results/pass4-stage.txt`,
`results/pass4-targeted.log`, `results/bench.log`; exit: `results/pass4.status`.
The entire acceptance matrix will finish even if an early numerical check fails,
to identify the full failure set. Strict gates still stop subsequent full tests,
final instrument, and the model matrices. No full model matrix has started.

The rest of this document is a chronological record; earlier running PIDs and
candidate descriptions are superseded by the later entries.

Read SPEC-FRAG.md, RESULTS.md and reviews/REVIEW-1.md. The previous matrix
and its supervisor/descendants were stopped on the test machine before syncing.
Its complete results directory is preserved under
`~/jevalloc/src-tree/results/interim-run1/`. The independent promptlab process
was left running. No machine address is recorded here. All work remains uncommitted.

Planned order: small lazy TLS/default-heap controls and acceptance; batched live
statistics and acceptance; remaining allocator findings; prompt v2; fragmentation
instrument validation; detached fragbench then regression matrices; final analysis.

Initial source diagnosis: static TLS embeds 256 large key entries; aligned none-mode
entry points lack a bypass; key-only uses an explicit no-reclaim heap; live mode
writes a global allocation clock and shared site counters on every allocation.

## First acceptance attempt

The first Linux build reduces PT_TLS from about 72 KiB to **81 bytes**. A detached
five-repetition control matrix is running (`results/acceptance-fix1.json`, progress
in `results/bench.log`). Early results **fail** the strict 3% gate: cfrac none/mi
score 1.062 and RSS 1.371; espresso 1.028 and 1.183. Larson's large TLS memory
penalty disappears in early repetitions, but time remains above the target.

A further confound was identified: linking the shim with the C++ driver forces
libstdc++ into C workloads, adding roughly 1.8 MiB. The next build makes C++ ABI
references weak on Linux, keeping C++ exception/new-handler behavior when a C++
program supplies its runtime. It also enables equal LTO/local-call optimization
for both allocator libraries. This requires renewed acceptance, not adjustment
of the recorded data.

Implemented locally, not yet accepted: sharded success counters with 256-object
merges, batched byte clock, reusable sample records, byte-weighted freed histograms;
reclaim-enabled tagged heaps and build-tree-only upstream reclamation patch;
heap failure checks; in-place realloc bookkeeping; realpath routing; exact raw
stack cache comparisons; separate key/model depths (4/12); versioned prompts.

Linux key normalization explicitly supports startup images only for this pass;
dlopen-created images remain outside the supported program set. No claim of
loader-safe dynamic image support is made.

The no-libstdc++ build passes the Linux fault-injection and C++ stress tests.
Early renewed cfrac measurements have none/mi time 1.004 and RSS 1.017, so that
additional RSS confound was material. Key-only still exceeded 3% RSS; the cache
is being reduced to 64 entries. Wider model stacks are now captured only on
cache misses, not on every live allocation. These changes invalidate reuse of
earlier acceptance records; they will receive a new run name.

The targeted Linux suite passed (cfrac trace/random, exact lifetime boundaries,
all interposition stress policies, live protocol/timeout/cache, replay fills,
model budget). The equivalent macOS cfrac-targeted suite also passed before the
latest cache-size change. Full `make test` remains pending.

Fragbench code now includes site-pure/site-mixed at 1/16 threads and two Redis
RESP workloads. It records phase RSS/live bytes and the ratio, plus peak RSS and
wall time. The instrument gate requires lower oracle idle RSS at both idle
phases and both site-pure thread counts, and binds the result to the library hash.
No full fragmentation or model matrix has been authorized by a passing gate yet.

## Live contention follow-up and portability

The five warm Larson observations in the second attempt still put live heuristic
around 2.2× oracle time. The 15% gate has **not** passed. Allocation counters alone
were insufficient: sampled histograms, live estimates and sample totals still
wrote shared cache lines. Those statistics now live in padded thread/site owners;
reference-counted owners survive thread exit while sampled objects remain, then
merge into the site and are freed. Sample record pools and locks are sharded;
recheck polling is local between bounded aggregation points. This implementation
runs the same statistics in cold and replay modes (no replay-only fast path).

A targeted macOS cross-thread test found that a C TLS recursion guard in the
mimalloc patch could recursively invoke the loader while initializing TLS. The
patch now uses the backing heap's existing no-reclaim guard during preparation,
which also prevents recursive reclaim while allocating heap metadata. The
three-tag thread-exit regression passes after this fix. C++ new-handler invocation
has explicit coverage in addition to bad_alloc and nothrow cases.

Reporting helpers now reject cold/fill/probe/failed/interfered records and require
exactly one accepted observation for every warm repetition, across the same
workload intersection. Live accuracy now selects explicit cold log paths and
separates policy answers from model-backed answers and unmatched-key coverage.

The first fully sharded diagnostic (one repetition, not acceptance) measured
live/oracle time ratios **1.37 on Larson** and **1.32 on xmalloc-test**, versus
about 2.2 on Larson before sharding sampled statistics. The latest build isolates
clock/control cache lines and merges success counters/clock every **1,024** successes.
It retains 1-in-64 lifetime sampling. This is still a true-live path; replay does not
skip the counters. Clock error can span pending bytes from every active thread.

The lazy key cache now uses an anonymous mapping: allocating its roughly 28 KiB
through mimalloc committed a larger medium-object page, undermining the small
control's 3% RSS target. The mapping is unmapped on thread exit, independent of
mimalloc destructor order. Table parsing and main-thread stack-bound discovery
also avoid stdio heap allocations. A new diagnostic and the five-repetition
site-pure instrument check are running sequentially on the remote machine.

The final isolated macOS cfrac-targeted suite passed, including the new tests.
Earlier overlapping local test attempts were invalidated by shared output paths;
only `build/pass4-tests-single.log` is the accepted local suite record.

Warm-run inference gating now publishes the existing repetition marker and waits
for the local server's `/slots` to be idle before starting timing. This lets the
independent prompt study finish its in-flight request, then obey its existing gate;
it is not stopped or paused by this project. Explicit run start/end timestamps
support a subsequent server-log interference audit.

## Instrument evidence (five interleaved repetitions)

The completed instrument check **passes both phases at both thread counts** on the
pre-final library (hash and raw phase observations in `results/pass4/instrument/`).
Final idle medians:

| Site-pure workload | mi RSS MiB | key-only RSS MiB | oracle RSS MiB | oracle / mi |
|---|---:|---:|---:|---:|
| 1 thread | 280.21 | 280.29 | 42.33 | 0.151 |
| 16 threads | 296.54 | 295.68 | 58.59 | 0.198 |

At the first idle point oracle was 22.64 / 41.29 MiB (1 / 16 threads), versus
key-only 122.29 / 136.69 MiB. Tagged, reclaim-enabled heaps do return free pages
with the common immediate-purge options; separate arenas are not needed to make
this instrument work. This is synthetic oracle evidence, **not** model evidence.
The check must be repeated after the final library changes before any long matrix.

The pre-final one-repetition diagnostic still fails the live target (Larson about
1.41× oracle; xmalloc about 1.34×). The last optimization adds a conservative
spatial negative filter for sampled pointers, so most unsampled frees can skip
the larger hash table. Four-bit filter counters saturate permanently positive;
collisions/overflow cause extra probes, never missed samples. Sampling remains
1/64, with unchanged site/clock semantics. `JEVALLOC_SAMPLE_FILTER=0` permits an
ablation. Final acceptance is not yet known.

## Final validation sequence

Final review caught a thread-destructor ordering issue: leaving the shim recursion
guard raised after freeing its cache would skip sampled frees made by later
application TLS destructors. Teardown now clears cached heap pointers and restores
the Linux recursion guard. A regression uses a later pthread-key destructor to free
all objects; sample rate 1 also exercises filter saturation. The superseded partial
full test log is preserved as `results/pass4-test-before-destructor-fix.log` remotely.

`scripts/pass4.sh` is the detached, fail-closed sequence: targeted Linux correctness,
five interleaved acceptance repetitions, full Linux `make test`, instrument recheck bound to the final
library and server-sim binary/options, fragbench matrix, then mimalloc-bench matrix,
then summaries and an inference audit. It writes `results/pass4.pid`,
`results/pass4-stage.txt`, `results/pass4.status` and appends stages to the remote
CODEX-REPORT.md. The long matrices are conditional on passing every gate; no failed
gate is waived. Logs, cold/fill decisions, stdout, stderr and phase records remain
on the test machine. The prompt study remains running independently.

## Review disposition

- Review §2: warm selection requires exact repetition sets, successful output and
  decisions, and excludes cold, fills/probes, rejected/interfered records. Shared
  workload intersection is used. Accuracy population and coverage are explicit.
- §3: static TLS cache removed; all listed aligned APIs share the centralized none
  bypass; key-only uses the default heap. `jev-explicit` / `JEVALLOC_POLICY=explicit`
  preserve the old one-explicit-heap control. Performance gates remain empirical.
- §4: success counters and sampled statistics are sharded; the clock is batched;
  sampled owners survive cross-thread frees. No replay-only instrumentation shortcut.
- §6: heap failure checks and injected tests; failed attempts excluded from successful
  bytes/clock; byte-weighted histograms plus sampled survival; in-place realloc with
  explicit logical lifetime bookkeeping; class tags retained across thread exit and
  receiving heaps created lazily; raw-stack identity checks; realpath routing.
- Dynamic Linux image loading is explicitly outside the supported program set,
  rather than claiming a loader-safe implementation. Metadata/bootstrap and work
  after the exit snapshot remain excluded. Concurrent exit statistics are approximate.
- The heuristic's long threshold/survival evidence are explicitly approximations,
  not the trace's retrospective truth. Oracle is a prior-trace byte-majority site
  label, not a per-object classifier or a bound on possible RSS policies.
- Historical evidence and caveats from the numerical/prompt audit remain archived;
  current RESULTS.md makes no new unmeasured model or Redis claim.

Further fast-path changes queued after the current test pass: replace per-allocation
sampling division with an equivalent countdown; parse stack-map address ranges
without pulling in scanf; route none-mode strdup/strndup/realpath directly to mimalloc.
The sampling period and decision schedule are unchanged. The destructor regression
now checks the targeted site's surviving samples, rather than incorrectly requiring
zero surviving samples from unrelated runtime/stdout allocations at process exit.
Per-site surviving-sample totals are included in the final stats file.

The next supervisor first builds and runs targeted correctness, then runs the full
five-repetition acceptance set. Only if that passes does it run full `make test`,
repeat the instrument on the exact final build, and start fragbench followed by
mimalloc-bench. A detached finalizer publishes complete tables only after every gate
and inference audit passes; otherwise it records the exact failed stage and measured
gates. The original in-flight test pass is allowed to finish before the restart.

Latest deployed source: targeted Linux suite **ALL TESTS PASSED**, including the
per-site destructor/saturation assertion, replay, budget, stress, exact lifetimes
and cfrac trace/random modes. Final-source macOS live tests also pass. The current
Linux PT_TLS segment is **97 bytes** (readelf), versus about 72 KiB originally.
The five-repetition acceptance run is active across all 22 workloads, supervisor
PID **1746341**, finalizer PID **1746342** (also recorded in remote PID files).
The full 10-variant model matrices remain conditional on passing the gates.
Local validation evidence is in `results/pass4/validation/`.

All 22 workloads in the preceding full test attempt completed trace and random
runs. That attempt failed an obsolete exact-count assertion on the **threaded** live
case: batched aggregation may legitimately skip the 1,024 quantization bucket. The
exact 1,024 assertion now uses a single-thread fixture; threaded tests require safe
rechecks without assuming an exact merged count. Separately, the destructor test
uses a precise per-site survivor assertion because runtime/stdout objects can remain
alive at exit. Targeted Linux and macOS live suites passed before this test-only
scheduling assertion correction; it is included in the queued full suite. Full `make test` is queued
again on the final source after acceptance, before the final instrument and matrices.

The corrected single-thread recheck test passed locally (`build/pass4-live-corrected.log`).
An additional fault-injection regression now repeats 2,048 failed allocations at one
site and verifies zero successful bytes/samples and no success-driven rechecks. It
is queued for validation. Reporting now states the numeric byte-classification
ceiling for each site-mixed trace. The finalizer was restarted as PID **1757873**
after making publication idempotent; the acceptance supervisor was not restarted.

Five completed cfrac acceptance repetitions: none/mi time **1.0212**, none/mi RSS
**1.0329**, key-only/none RSS **1.0035**. Thus the 3% no-policy RSS gate still fails
on this workload (147,456 additional bytes). Other workload acceptance is running;
no inference/model matrix has been authorized by an unpassed gate.

The 2,048-failure accounting regression passed locally
(`build/pass4-live-accounting.log`). A further candidate now avoids all keyed
startup initialization in ordinary none mode, while the public key diagnostic
initializes it lazily. Live before/after/free paths inline only their unsampled
checks; decisions, sampled records and locks remain in out-of-line slow paths.
The recheck poll counter now shares the thread-owned success-counter cache line.
No sample rate, class decision or threshold was changed. This candidate is under
local correctness validation and has not replaced the remotely measured library.

The countdown-build acceptance attempt was stopped after cfrac, espresso, barnes
and larson completed five repetitions each. Larson live/oracle was **1.3371**,
above 1.15. Raw logs were moved to remote `results/logs/acceptance-countdown`;
record paths were updated accordingly. The matching source and library are retained
under remote `results/pass4-attempts/countdown`, and the matrix was fetched to
`results/pass4/attempts/acceptance-countdown.json`. Supervisor and descendants are
confirmed stopped; the independent prompt study was not signaled. The old supervisor's
SIGTERM trap wrote 0; the archive explicitly marks this as a manual stop, not success.

The next candidate also derives surviving samples/bytes from sampled totals minus
frees, removes redundant atomic RMWs under existing sample locks, and places each
reusable sample-record pool head beside its padded mutex. It preserves sample rate
64 and the same statistics. Completed recheck schedules no longer poll every 64
allocations. The inline-only candidate passed local targeted tests; the additional
counter changes are now being tested on both machines. Detached remote diagnostic
PID **1859634** writes `results/pass4-diagnostic.status`, stage/log files, and
`results/diagnostic-inline.json`. This is one repetition for cfrac/larson/xmalloc,
not acceptance and not either requested model matrix. No finalizer is active until
the acceptance supervisor is restarted.

The counter/inline candidate passed targeted correctness on Linux and macOS
(`results/pass4/validation/pass4-inline-targeted.log`, local
`build/pass4-counter-tests.log`). Its one-repetition diagnostic measured
cfrac none time/RSS 1.027/1.001 and key/none RSS 1.005; larson live/oracle 1.219;
xmalloc live/oracle 1.168. xmalloc none time was 1.074, so it is not evidence of
acceptance. These diagnostics are in `results/pass4/attempts/diagnostic-inline.json`.

The inference audit initially reported one 20 ms overlap at the end of the last
cfrac oracle run. Source inspection of the running server showed that the log's
wall-clock origin is distinct from /proc process-start time. Calibrating paired
release log timestamps and LRU `t_last_used` monotonic values puts the logger origin
**206.082 ms later**; ten recent pairs agree within 1.2 microseconds. The corrected
audit finds **zero overlaps in 106 recorded warm runs**, including the incomplete
next workload. The calibration pairs are preserved in the fetched audit JSON.
The performance failures are unchanged. Future acceptance and both full matrices
require this calibrated audit, with PID-start identity checked separately.

Detached diagnostic PID **1881923** now runs a rare-sampling ablation followed by
a SIGPROF CPU-PC profile of Larson. `perf_event_paranoid=4` prevents ordinary perf
profiling; the small Linux-only diagnostic sampler allocates nothing in its signal
handler. These runs carry diagnostic markers and cannot enter headline selection.
Production sampling remains 1/64. The normal supervisor will run build, acceptance
plus inference audit, full make test, exact-build instrument, fragbench, then
mimalloc-bench; it no longer repeats the already passed targeted suite on startup.

The rare-sampling ablation (1/1,048,576, diagnostic only) measured Larson live/oracle
**1.1161**, versus 1.2194 at the unchanged production 1/64 rate. A 2,224-sample
SIGPROF profile attributed about 28.5% to capture, 16.2% to mimalloc allocation,
8.1% to the shim allocation path, 5.7% to shim free and 5.0% to mimalloc free.
This is a coarse CPU-PC profile, not a blocked-time attribution or acceptance run.
Raw PCs and both diagnostic matrices are retained under results/pass4/attempts.

A page-local negative filter is now under validation (remote diagnostic PID
**1895434**). It uses mimalloc's unused padding word without changing page size;
`mi_segment_page_clear` already zeros that word after the last object is released,
and abandonment/reclamation retain it with live objects. The old spatial filter
remains selectable. Saturation is conservative. This candidate has not yet
established the 15% gate. Production sampling is still 1/64.

Owner-local class publication and its threaded long-to-short heap-tag regression
passed Linux tests. The candidate also removes recursion-guard writes from
unsampled frees and moves C++ handler/exception work to a cold failure path.
One-repetition owner candidate: Larson live/oracle 1.2151; xmalloc 1.1652, with
xmalloc none/mi time 1.0132. This still did not establish the 15% gate.

The latest candidate keeps normalized model frames out of the key-only cache:
12 KiB for keyed-only state, plus 16 KiB only when instrumented. Merge batches are
now 4,096 successes per thread/site, also flushed before decisions and at thread
exit; sampling remains 1/64, and the single-thread 1,024 recheck remains exact.
Larger batches make cross-thread clock/count snapshots coarser. Both targeted
suites passed. Diagnostic PID **1940146** is the current measurement job.
Full-suite reports now carry the tested library hash and a full-suite flag; final
publication checks that acceptance, tests and both matrices use the same library.

The compare attempt (supervisor 1962789) was stopped after its five cfrac
repetitions failed the key-only RSS limit. Results and source/library are preserved
under `results/acceptance-compare.json` and `results/pass4-attempts/compare/` remotely.
A diagnostic smaps probe identified additional cold libc pages in keyed mode;
image initialization now avoids filename substring search. The sampled pointer
hash previously mapped 1 KiB aligned blocks within a page to just two sample
locks. It now uses the existing full integer mixer. Neither change is accepted yet.

The hash candidate passed targeted Linux and macOS correctness. Its short
comparison is running as PID 1976680. Two further local edits await Linux validation:
main-stack discovery uses a small address/protection prefix buffer and a narrow
hex parser; the raw-PC cache index mixes all bits so inner call sites do not vanish
from the index after rotations. Exact PC/count comparison still establishes cache
identity. These changes do not alter normalized site keys or sampling rate.

The cache diagnostic measured live/oracle time 1.2017 on Larson and 1.1751 on
xmalloc (one repetition, not acceptance). Cfrac live/oracle fell from 3.1907 to
1.5553 after mixing the raw-PC index. Key-only RSS remained 1.034735 of none.
The next candidate aliases ELF free directly, moves trace-only recursion work
out of the live free path, and releases Linux contexts through mimalloc's existing
thread teardown before heap abandonment. This removes a redundant pthread key and
its cold libc paths. The core-only patch now includes init.c; the vendor and plain
mimalloc remain unchanged. Targeted lifecycle validation precedes timing.

The lifecycle candidate passed targeted Linux and macOS tests, including retained
class tags and late TLS-destructor sampled frees. Its measurement is still running.
Further local changes avoid pthread_once in the already serialized loader
constructor (retained for the public none-mode lazy key API), and ask LTO to inline
the small mimalloc free path while keeping sampled/trace slow paths out of line.
The latter lets the negative filter and free reuse page lookup work; these edits
need their own Linux correctness and performance checks.

The broad `flatten` experiment was rejected: GCC pulled cold allocator paths into
free, increased its stack frame dramatically, and produced a strong C++ RTTI
reference that failed the C fault-injection executable. It was removed before any
benchmark from that candidate. The replacement exposes only the ordinary free
body with an already-resolved page, leaving baseline/vendor free unchanged.
Linux targeted tests passed for that helper plus a thread-local live-site hash
index; macOS passed for the helper before the index was added. The index removes
linear live-shard lookup after raw-cache collisions.

A five-repetition bootstrap diagnostic (cfrac controls only) still measured
none/mi time 1.01218, RSS 1.00000, key/none RSS 1.034735. External peak smaps
sampling showed only 16 KiB actual RSS difference in one paired diagnostic, despite
a much larger ru_maxrss difference; file faulting/accounting is significant at
this scale. The acceptance metric and threshold are unchanged. The parser for
the oracle table is the remaining keyed-only use of libc's general integer parser;
a checked narrow parser now awaits Linux validation, with overflow/truncation tests.

The pagefree diagnostic completed: Larson live/oracle 1.2048, xmalloc 1.1687,
so the 15% gate remained unmet. A 9,911-sample SIGPROF run attributed 33.5% to
capture, 9.8% to shim free and 2.1% to the core page-aware free. The next candidate
uses a one-multiply pointer hash, omits unused live capture outputs, and loads
model frames only on the live slow path. It also includes the checked table
parser. The shared core free body is now factored once, rather than duplicated.
Targeted Linux tests passed; compact diagnostic PID 2072047 is measuring it.

Disabling the negative sample filter worsened the diagnostic Larson live/oracle
ratio to 1.2839, so page filtering remains enabled. The new candidate keeps the
1/64 sample rate: power-of-two sampling uses the existing allocation count instead
of writing a separate countdown; arbitrary rates retain the countdown. Hot owner
fields fit the first cache line. Sample-table locks use a test-and-test-and-set
loop with processor pause and bounded spinning before sched_yield. Their acquire/
release ordering and exact pointer membership are unchanged. Direct ELF C++ new/
delete aliases remove forwarding jumps. Full supervisor 2101937 is validating
this candidate and will collect all 22 acceptance workloads before evaluating gates.

The sampler candidate passed targeted Linux and macOS suites. ELF PT_TLS is
**105 bytes** (0x69); free/delete and scalar/array new aliases resolve to identical
target addresses as intended. The full 22-workload, five-repetition acceptance is
running. Its input tables, traces, source, libraries, and targeted test log were
frozen before any later full make test under
`results/pass4-acceptance-inputs/sampler/` on the test machine. Local validation
records are in `results/pass4/validation/sampler-*`.

## Review disposition and historical evidence

The numerical audit was independently recomputed from the committed interim JSON:
`results/pass4/review-audit.json`. Warm-only heuristic score is 2.073610 (rounds
2.07); static/model are 2.056944/2.068057. The old prompt study's always-short
baseline is 55/92 = 59.78%, and the two-answer prompt has medium recall 0/31,
not 2/31. These are historical corrections, not new allocator results.

Archived cfrac cold decision logs and the archived oracle table now reproduce the
previously unverified accuracy numerators: static 68/175; model first 77/175,
rechecks 146/187, final-per-site 109/175. Every decision key matched truth, and
policy/model-only populations agree for these specific logs. Rechecks remain
repeated decisions over a different population, not independent sites. Evidence:
`results/pass4/review-evidence/` and `results/pass4/review-old-accuracy.jsonl`.
The accuracy tool now withholds scores on unmatched truth keys and supports the
fragmentation matrix's table directory; its regression test passed locally/remotely.

Sections 3/4: lazy small TLS, consistent default-heap controls, tagged reclaim,
thread-owned success counters, batched clock and lifetime-safe sampled owners are
implemented; performance acceptance is still pending. Section 6: heap failure,
failed-success accounting, byte-weighted survival-aware heuristic, in-place realloc,
class tags across exit, exact raw-cache identity and realpath routing have targeted
coverage. Linux dynamic image loading is explicitly unsupported (startup set only),
as the review allows. No general leak of mimalloc's normally deleted heaps is
claimed. The oracle is a prior-trace site majority, not a per-object or RSS bound.
Legacy microbenchmark, CPU/Vulkan speed and lifetime-distribution claims are not
reused as new evidence. The original report is preserved unchanged as an archive.

Current sampler acceptance has completed cfrac, espresso, barnes and Larson.
All four pass the memory/control gate; Larson live/oracle is **1.188301**, failing
1.15. The supervisor continues through all workloads to collect the full failure
set; this established failure will keep it from starting the full model matrices.

A local follow-up is under macOS validation and has NOT been synced to the running
Linux build: allocation counters are private non-atomic owner fields; exit reporting
reads only published totals when workers remain active. Finished/joined threads
still publish every success; active workers can leave up to 4,095 unmerged allocations
per thread/site. An admitted in-flight allocation no longer rereads the global close
flag after raw allocation. Two cold-path corrections avoid rewriting immutable
none-mode flags during lazy key initialization and reject an uninitialized default
heap before class-tag lookup. These edits require fresh Linux tests and acceptance.

The first 11 completed sampler acceptance workloads establish failures in xmalloc
none time (1.0473) and mstress key/none RSS (1.0526), in addition to live time on
Larson, Larson-sized and xmalloc (about 1.19). Mstress live time passes at 0.9583.
The matrix is still collecting the remaining workloads. The follow-up private-counter
candidate passed the macOS targeted suite. It additionally requests inlining of
only the small raw/page-aware free entry points (not recursive flattening), to
remove forwarding cost and expose shared page calculations to LTO. Linux validation
waits until the current acceptance finishes; no build is changed during timing.

The archived traces now also reproduce all six historical site-class counts with
zero oracle-table mismatches. `tools/trace_distribution.py` reproduces
`results/pass4/review-lifetimes.json` from the retained evidence. Actual object-byte
shares differ from whole-site majority shares: Larson is 2.433% short, 96.906%
medium, 0.661% long, whereas assigning every byte its site's majority class gives
99.9997% medium. Mstress has 0.907% actual short bytes despite zero short-majority
sites. Cfrac/espresso/Redis actual short shares are 99.963%/99.503%/99.814%; Barnes
is 100% long in this trace. These are cumulative requested bytes, not a bound on
resident fragmentation or page pinning.

The mstress key-RSS failure is not evidence of a 5% cache footprint: raw five-run
peaks span 502,096–534,580 KiB for key-only and 500,704–534,452 KiB for none, with
medians falling into different clusters. Thread scheduling and segment retention
are plausible contributors, not established causes. The specified five-run median
and 3% gate remain unchanged; this run is still a failure.

Thirteen workloads are complete. Rptest live/oracle passes at 1.0885, but none/mi
RSS is 1.0375 and fails; glibc-simple passes. No thresholds are changed. Report
publication now regenerates acceptance from its input matrix and requires each
inference audit to carry that matrix's SHA-256, preventing stale evidence reuse.
The obsolete countdown restart helper was removed locally.

The completed glibc-thread check fails none time at 1.0598; alloc-test1/N and
malloc-large pass. Mleak10 fails key-only/none RSS at 1.2011. Its mi peaks span
8,364–24,752 KiB, none 16,500–22,564 KiB, and key-only 16,508–24,776 KiB. The
thread-churn benchmark is highly variable in this run; that is recorded alongside
the failed gate, not used to discard observations or change acceptance.

## Pass 5 start — two classes (2026-10-10)

Read SPEC-TWOCLASS first; it supersedes the old strict performance gates. Remote
inspection found pass4.status=1 and no supervisor/finalizer still running. Acceptance
stopped in the Redis heuristic cold run with a live-decision failure, after earlier
workloads completed. Its JSON is retained locally at results/pass5/prior/acceptance-final.json;
remote raw logs and frozen sampler inputs remain untouched. Round4 promptlab is
running independently and has not been signaled or modified. Preserve all existing
uncommitted fixes, including the locally validated private-counter follow-up.

Implementation direction: exact fixed-threshold trace classes (short < S, long >= S
or never freed), default long, two tagged heaps, new cache identity, hand-written
program descriptions, and 64 KiB/1 MiB/16 MiB oracle sensitivity. Performance misses
will be measured and reported, not block the fragmentation/model matrices.

Initial two-class macOS targeted suite passes, including stress, trace consistency,
heap failure, retained tags through thread exit, late destructor frees, live rechecks,
replay coverage and budget integration. New tests check S exactly and S+1 separately.
Descriptions in descriptions/*.txt are hand-written from local source/docs, not model
outputs; they are code-side input and do not contain measured oracle labels. The old
Redis failure had no timeout or sidecar exception; errno was not recorded. The new
build records failure_errno to diagnose a recurrence without discarding the run.
A short two-class instrument/Redis diagnostic follows Linux targeted correctness.

The two-class diagnostic labels >99% of session bytes long at 1 MiB, as it does
cache entries: this workload's former medium/long separation is gone. One-rep
oracle RSS is essentially equal to key-only (and worse at 16-thread first idle).
This is a classification/instrument limitation, not evidence of failed page purging;
the earlier three-class positive control stays archived and is not reused as a
passing two-class instrument. Five repetitions and threshold sensitivity are next.

Redis diagnosis: failure_errno=111 (ECONNREFUSED), always after 574 decisions, no
sidecar error. live_init retained getenv storage for the socket path; Redis's
setproctitle overwrites original environment storage. Copying the path in init is
under test, with a regression that zeros the original JEVALLOC_SOCKET value in the
application. This is a pass-4 correctness fix retained in pass 5.

Prior sampler acceptance completed 21/22 workloads. Target misses: Larson live/oracle
1.1883, Larson-sized 1.1913, xmalloc 1.1946 (and none/mi time 1.0473), mstress key RSS
1.0526, rptest none RSS 1.0375, glibc-thread none time 1.0598, mleak10 key RSS 1.2011,
sh6bench none time 1.1018 and live/oracle 1.7720, sh8bench none time 1.0556 and
live/oracle 1.4846. Redis is incomplete. No more micro-tuning is planned: residual
capture/sampling work and noisy page/thread accounting are suspected contributors.

The Linux cache repeat test exposed a pre-existing exemplar instability: a site uses
four key frames, but rechecks took twelve model frames from whichever direct-mapped
cache entry last survived ASLR-dependent collisions. Counts/keys matched; outer
frames differed in one recheck. LiveSite now retains its first observed model stack
for all rechecks, matching trace site's first-observation convention. This avoids
cache layout changing the model's code evidence without changing key depth.

A final snapshot guard is queued before timing: concurrent sampled allocations/frees
can straddle the live totals read, so bound live/short partitions before subtracting
and rendering percentages (prevent unsigned wrap). This source-only fix has not
changed the active Linux full-test binary. The current full suite is allowed to
finish; the guarded build will receive its own full suite before headline timing.
All three fixed-socket Redis diagnostic runs completed without failures. The native
two-class prompt/tool tests also check legacy replay rejection and exact histogram
threshold reconstruction; non-power-of-two sensitivity requires retracing.

Instrument decision: preserve the requested 400,000-object server workload and its
actual fixed-S truth. Do not rescale it below S just to recreate the old positive
control. If the five-repetition nominal oracle fails to lower every idle RSS,
continue only with explicit --allow-negative-instrument, recording the negative
and its investigation. This is an interpretation of SPEC-TWOCLASS's direction to
finish the matrices, not a claim that the strict SPEC-FRAG instrument target passed.
The runner still requires complete instrument measurements on the identical library,
server binary, options and threshold before allowing this explicit continuation.

Prompt fitting now shortens source lines only; program description and runtime
percentages survive the 3,000-token budget. The former uniform line clipping could
cut off "kept longer"/"never freed" percentages. A tokenizer-mocked regression
checks that all three call markers and the final percentage survive. v2 remains
the matrix default; no-description and runtime-only variants are selectable in
jevd and both runners. Model probability maps must contain exactly short/long.

Prior acceptance audit: **zero inference overlaps in all 525 warm runs** (21 complete
workloads × 5 variants × 5 repetitions), with calibrated logger origin and matrix
SHA binding; JSON retained in results/pass5/prior. Final guard build is queued by
scripts/pass5-continue.sh after the currently running suite/instrument exits. It
archives those pre-guard outputs, rebuilds, reruns full correctness, then runs
instrument, fragbench, table sensitivity, regression and report via pass5-final.sh.
No performance threshold will be presented as passed when it failed.

The bounded-snapshot build passes the macOS targeted suite (results/pass5/validation/
macos-targeted-final.log). The Linux queue PID is 3909734; it waits for the first
suite/instrument, then reruns full tests on the final build. The final source and
prompt are frozen; only analysis/report helpers may change during measurement.

The sidecar can share a raw model-response cache for identical native two-class
payloads; the runners use results/pass5/model-cache. This avoids repeating exactly
the same initial code-only question for static-model and model, or Redis Mesh/drop.
Cached answers still consume each policy's 400-decision budget, replay/fills reserve
those slots, and original backend provenance remains attached. Decision schedules
and runtime requests remain separate per workload/policy. No old three-class cache
is imported. A unit test verifies both cache reuse and unchanged budget consumption.

The first full Linux suite passed all 22 workloads. Its five-repetition two-class
instrument is negative: first idle at 16 threads is oracle/key-only 1.0064; final
idle is 0.9892. Single-thread oracle/key-only is about 0.9992. Raw pre-guard results
are archived in remote results/pass5/prior/instrument-before-snapshot-guard.
The final guard build is now running its own full Linux suite.

A fragbench scope correction is necessary for the requested hard tier: the old
site-mixed TTL choices both survived past S, making it almost entirely long under
two classes. Site-mixed now has request-data TTL=0 payloads freed in the current
operation (50%), payloads released at the load drop (45%), and never-freed payloads
(5%, which is 10% of peak live payload slots). The same store_request_payload call
produces both short and long; per-site labels cannot separate them. Site-pure's
400,000-object workload is unchanged. Original mixed source is retained in
results/pass5/prior/server-sim-before-mixed-ttl.c. This corrects the hard-tier
contract; it does not rescale the negative site-pure instrument to manufacture a win.

Final source snapshot is retained remotely at results/pass5/source-final.tgz.
Validated-build candidate SHA-256: c15e9f5ca2e429f883b5e93db1b110d1fb44f443b6b16d07a713fc96e28f7195.
Server binary SHA-256: ad90ff9df10c0185c48702c1fdf83cab14ca3389a189a53a575f2904a6150330.
The Linux TLS segment is 97 bytes. The new mixed-tier phase smoke check passed;
its measured timing/RSS is diagnostic only because full correctness was concurrent.

## Final two-class validation and active matrices

Full Linux correctness PASSED on c15e9f5ca2e429f883b5e93db1b110d1fb44f443b6b16d07a713fc96e28f7195;
all 22 trace/random workload pairs plus live protocol, invalid class 2 rejection,
setproctitle/environment mutation, replay, exact S boundaries and budget tests.
Logs/manifest are copied to results/pass5/validation. Final instrument gate there
contains all four five-run comparisons and the matching server/library hashes.

Fragbench is now running, with twelve variants including all-short/all-long, five
interleaved repetitions and a 400-answer budget per cold model policy shared with
fills. Supervisor PID 3909734; progress results/pass5/stage.txt and results/bench.log.
It will run table sensitivity before the regression matrix. Preserve active code,
tables and native response caches. If interrupted after the supervisor stops, use
fragbench/run.py --name fragbench-two --allow-negative-instrument --resume to resume
only when fingerprints match; do not rerun the historical pass4 supervisor.

First completed two-class workload (site-pure-1, five repetitions): mi idle RSS
280.16 MiB; key-only 280.29; oracle 280.07; heuristic 282.88; static-model 283.10;
adaptive model 280.84. Uniform all-short/all-long are both about 280.30 MiB. Random
is 42.55 MiB, with wall time 1.161 s versus mi 1.087 s (common 1 s settle included).
This is an important positive control: two tagged heaps can release memory, but
S=1 MiB assigns both sessions and persistent cache entries long. Random happens to
separate them. The byte-majority lifetime oracle is emphatically not an RSS optimum.
These are complete workload medians, but the full matrix/audit is still pending.

## Workload attribution correction — partial matrix archived

Source attribution exposed GCC identical-code folding: all four tiny lifetime
wrappers resolved as parse_request_buffer in addr2line, although their caller PCs
still made distinct keys. Thus the model received misleading stack names; session
and cache prompts could collapse to the same source context. The first matrix is
being stopped cleanly and preserved, not published as final model evidence.
CMake now disables GCC IPA identical-code folding for server-sim only. The allocator
library c15e9f... is unchanged; its full validation remains valid.

At the same workload revision, TTL choices use the seeded PRNG instead of i%20.
The periodic pattern aliased 1-in-64 sampling (some retained TTL positions could
never be sampled). Probabilities remain 50% immediate, 45% load-drop, 5% retained;
actual trace shares and ceiling are measured. No sampling rate/policy is changed.
Only server-sim is rebuilt. Unique wrapper PCs/debug names, phase behavior and trace
consistency will be checked, followed by a fresh instrument and full fragbench.

## Distinct wrapper and genuine mixed-site validation

The first corrected workload validation deliberately stopped before any matrix:
GCC branch threading duplicated the mixed allocation call based on TTL, making
short and long populations separately classifiable despite identical source lines.
TTL selection is now a noinline function, preserving one common allocation PC.
A trace-based check requires exactly one payload site with 40–60% short bytes and
3–7% never-freed bytes, four distinct pure wrapper symbols, consistent trace totals,
and drop/idle live-byte accounting at both 1 and 16 threads. All four checks pass.
Pure workload byte-majority accuracy ceiling is 99.932%; genuine mixed is 83.374%
(single thread) / 83.394% (16 threads), including the pure temporary sites.

Final server SHA-256: 2bd8e95865531b34a715b536d99b4519b93c85c516464724ff31ce4920f5a5c9.
Allocator remains c15e9f5ca2e429f883b5e93db1b110d1fb44f443b6b16d07a713fc96e28f7195.
The failed validator supervisor 4042611 exited 1; its successor is recorded in
results/pass5/frag-finish.pid. The archived first matrix and its earlier numerical
commentary are superseded, not combined with this build's measurements.

Corrected supervisor PID 4044072 passed workload validation and completed the
five-run instrument. Oracle/key idle ratios: 0.99859 and 0.99907 (1 thread),
1.00685 and 0.98705 (16 threads). This again fails the strict every-phase gate;
fixed-S session/cache label merging remains the explanation. The full matrix
continues under the recorded explicit override. Frozen source and executable copies
are remote results/pass5/source-distinct.tgz and results/pass5/frozen-distinct/;
local validation has the source archive, checks and checksums. The original full
Linux library suite remains applicable. Current model cold stage: site-pure-1.

Report maintenance: tools/report.py now routes to the audited pass-5 report instead
of emitting obsolete three-class prose or replacing the interruption journal. Its
previous source is preserved as results/pass5/prior/report-pre-pass5.py. README
uses the fixed-S sampled byte-share heuristic, native two-class size baseline and
current pipeline. Report covers cold/fill costs separately, validates the shared
400-slot budget, and scores explicit cold logs with matching-key coverage.

Corrected site-pure-1 cold collection completed: static 183.8 s wall / 181.4 s
model HTTP, adaptive 318.9 s wall; zero decision errors. Four main lifetime paths
have distinct debug attribution and static labels match trace-majority truth.
Warm five-repetition collection has started. Report inputs now additionally audit
the instrument and verify every fragbench oracle table against exact trace labels;
actual object-byte distributions stay separate from whole-site majority assignments.

Corrected site-pure-1 block complete, 60 accepted warm runs; independent audit has
zero inference overlaps (snapshot in results/pass5/progress). Median final idle MiB:
mi 280.22, key 280.30, oracle 280.07, random 42.55, heuristic/static/model 282.87.
All-short/all-long both 280.29. Oracle labels merge sessions/cache; the seeded random
control separates them and releases pages, on this same corrected build. Model
labels for all four main allocation paths match oracle truth, without an RSS win.
Median model wall 1.141 s vs mi 1.087 s includes a common 1 s settle; CPU is 0.128
vs 0.086 s, about 1.49x. Report now states CPU ratios to avoid masking work behind
settle time. Five repetitions are descriptive, not an equivalence test. Workload
site-pure-16 cold collection is in progress; no complete-matrix claim yet.

Both corrected site-pure blocks complete (2/6 workloads). On 16 threads the observed
oracle/mi final-idle RSS ratio is 0.993; adaptive/heuristic 0.997, adaptive/oracle
1.026. Differences between adaptive and heuristic are small relative to run ranges.
The site-mixed-1 cold phases completed with 10 static and 23 adaptive decisions,
24.6 / 67.6 new HTTP seconds respectively, before warm collection. Existing identical
native payload answers are reused and still charged to the per-policy budget.

Site-mixed-1 complete (3/6). Median idle MiB: mi 144.71, oracle 144.97,
heuristic 146.50, static 146.88, adaptive 146.87. Adaptive/heuristic ratios:
RSS 1.003, wall 0.940, target CPU 0.637. Thus this workload shows a time/memory
tradeoff, not a fragmentation win. Main payload static/adaptive predictions remain
long, while its trace-majority class is short near the 50% boundary; do not assume
higher oracle-label accuracy optimizes execution cost. Mixed-16 cold passed with
10 static / 23 adaptive decisions; static reused all native payload answers and
adaptive added 79.2 HTTP seconds. Warm collection follows, then both Redis tasks.

All four corrected synthetic workloads complete (4/6). Mixed-16 ratios:
oracle/mi idle RSS 1.022; adaptive/heuristic RSS 1.008, wall 0.996, CPU 0.923;
adaptive/oracle RSS 1.104, CPU 0.774. Warm ranges remain in the matrix. Redis Mesh
trace has 621 sites, 100,951,634 short and 318,292,001 long requested bytes, with
99.964% prior-trace per-site classification ceiling. Heuristic cold passed with
653 decisions (model-free). Static model cold is active, limited to 400 answers;
startup-site coverage will be reported rather than assuming all sites were asked.

All 22 full-suite regression traces match their two-class oracle tables (zero label
mismatches). Distribution evidence is in local validation/regression-trace-distributions.json
and remote results/pass5/regression-trace-distributions.json. Actual short requested
byte shares: cfrac 99.96%, espresso 99.50%, barnes 0%, larson 2.43%, mstress 0.87%,
Redis 99.81%. These are actual object-byte sums, not the proportion of all bytes
assigned to a majority-short site. The full report regenerates both quantities.

## Pass 6 start — transient/permanent boundary (2026-10-10)

SPEC-PERMANENT.md takes precedence. Inspected the remote state first: supervisor
4044072 was collecting static-model Redis Mesh decisions. Signaled only that
supervisor and its descendants, confirmed they exited, and moved pass5,
fragbench-two, frag-instrument and bench.log into results/pass5-shortlong/ remotely.
The archive includes snapshots of this journal and RESULTS.md. Four completed
synthetic blocks remain the wrong-boundary finding; partial Redis is not complete.
The independent round4 prompt process is untouched. promptlab5.py and round5.sh
exist but no round5.log/results yet; use SPEC-PERMANENT's default wording.

Implementation: default transient; byte-majority ties transient. Trace schema 3
spools exact freed lifetimes in an unlinked file beside the trace output, then
classifies against final requested allocation volume with integer comparisons.
Permanent means never freed or strictly greater than 25/50/90 percent of total
volume (50 default). Never-freed-only and fixed-S controls are separately named.
Old traces and decision/replay caches are rejected, not silently relabelled.

Live heuristic: deterministic uniform reservoir of 128 sampled allocations per
site, across all its threads and its entire observed history. Each entry retains
birth allocation-clock, requested size, serial and whether it has been freed;
replacement is independent of survival. At a decision, take the count median age
of that reservoir (lower median for even counts), and consider entries strictly
older than it. With at least 16 entries and nonzero older bytes, permanent iff
20 * freed older bytes < total older bytes (strictly under 5%); otherwise transient.
No final-run length is used. Small/equal-age cohorts default transient. Reservoir
updates occur only on sampled allocations/frees, under a per-site lock; unsampled
paths are unchanged. Batched clocks and finite reservoirs remain approximations.

The first macOS targeted suite PASSED: cfrac trace/random, trace volume/sensitivity
accounting, fault injection, retained two-class tags, late destructor frees,
setproctitle socket preservation, sidecar timeout/invalid-class handling, deterministic
live requests, replay coverage and budget fallback. New default assertions now expect
transient. The full Linux suite is running before the instrument. The reservoir
adds only sampled-path work; its cost will be measured without a performance gate.

The reservoir transition integration also passes on Linux (sample rates 1 and 64):
one allocation PC transitions transient -> permanent while objects are held ->
transient after meaningful frees, including reuse of sampled pointer addresses.
The 25/50/90 trace fields agree with known fixture lifetimes; fixed-S exact-boundary
checks remain separate. No old short/long cache is imported.

Validation supervisor is remote PID 4063666. Queued successor PID 4072866 waits for
successful full correctness and the instrument. The instrument includes random,
requires oracle <= random at all four idle points, and oracle < half mimalloc's RSS.
A failed instrument stops the queue for investigation, without using the old
negative-instrument override. On success: site-pure sensitivity (25/50/90/never
plus three separately named fixed-S controls), then all six fragbench workloads,
then all 22 regression workloads, with five interleaved repetitions and 400 model
answers per cold policy including fills. Progress is results/pass6/stage.txt and
results/bench.log; status files are results/pass6/validate.status and pass6/status.

Before any pass-6 performance measurements, alloc-testN tracing exposed an avoidable
18 GB spool. Validation and the queued successor were stopped and their partial
outputs preserved in results/pass6/before-spool-pruning. Exact pruning now skips a
freed lifetime if it is <=25% of the current clock: the final clock cannot be smaller,
so the object cannot qualify at any supported permanent fraction. This preserves
all exact class results while eliminating immediate/short lifetime records. Full
correctness is restarted on the revised library; the earlier hash is superseded.
No performance run from that library is being reused.
