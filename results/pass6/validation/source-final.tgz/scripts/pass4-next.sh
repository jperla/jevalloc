#!/usr/bin/env bash
# Finish the already running test pass, then validate the final source snapshot.
set -euo pipefail
cd "$(dirname "$0")/.."
old_pid=$(cat results/pass4.pid)
while kill -0 "$old_pid" 2>/dev/null; do sleep 10; done
if [[ -f results/pass4-test.log ]]; then mv results/pass4-test.log results/pass4-test-before-countdown.log; fi
if [[ -f results/pass4.status ]]; then mv results/pass4.status results/pass4-before-countdown.status; fi
nohup bash scripts/pass4.sh >results/pass4-supervisor.log 2>&1 </dev/null &
echo $! >results/pass4.pid
nohup python3 tools/pass4_finalize.py >results/pass4-finalize.log 2>&1 </dev/null &
echo $! >results/pass4-finalize.pid
