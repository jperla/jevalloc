# jevalloc — transient/permanent pass in progress

**Status: pass 6 correctness and instrument validation are running.** The previous short/long fragbench was stopped and archived remotely in `results/pass5-shortlong/`. All numbers below are historical wrong-boundary evidence from pass 5; no transient/permanent performance claim is made yet.

Each row below uses five accepted interleaved warm repetitions. All 240 synthetic warm intervals have zero model-inference overlap. Cold inference and coverage runs are excluded. The allocator uses short (freed before another 1 MiB of requested allocations) and long (everything else), with unknown sites defaulting to long.

| Workload | mi idle MiB | Oracle | Heuristic | Static model | Adaptive model | Adaptive wall/mi | Adaptive CPU/mi |
|---|---:|---:|---:|---:|---:|---:|---:|
| site-pure-1 | 280.22 | 280.07 | 282.87 | 282.87 | 282.87 | 1.049 | 1.482 |
| site-pure-16 | 295.50 | 293.45 | 301.94 | 297.84 | 301.10 | 1.020 | 1.096 |
| site-mixed-1 | 144.71 | 144.97 | 146.50 | 146.88 | 146.87 | 0.993 | 0.873 |
| site-mixed-16 | 146.43 | 149.65 | 163.84 | 165.47 | 165.22 | 1.002 | 0.886 |

The [full synthetic table](results/pass5/progress/synthetic-summary.md) includes all twelve variants, five-run ranges, live bytes, fragmentation ratios, peak RSS, wall/CPU costs and comparisons with the oracle. The [matrix snapshot](results/pass5/progress/fragbench-synthetic-complete.json) and [inference audit](results/pass5/progress/fragbench-synthetic-complete.inference-audit.json) preserve the observations.

The fixed-S oracle gives both long-running sessions and never-freed cache entries the long class. It therefore shows little or no idle-RSS benefit. The seeded random table happens to separate them in the pure tier: single-thread idle RSS is 42.55 MiB versus 280.22 MiB for mimalloc. This demonstrates useful physical separation on the same build, while showing that lifetime-label accuracy is not an RSS optimum.

In the mixed tier, one site produces both immediate and retained allocations. A fixed site label cannot separate them. Clef uses less CPU than the heuristic in the observed medians, with higher idle RSS. The common one-second synthetic settle period makes CPU costs more visible than wall-time ratios. Five repetitions do not establish statistical equivalence.

The five-run instrument still fails its strict requirement that oracle idle RSS be lower at every point: oracle/key ratios are 0.9986 and 0.9991 at one thread, and 1.0069 and 0.9870 at sixteen threads. Its 30 warm intervals are separately audited. The full matrix proceeds with this investigated negative result recorded.

Program descriptions are hand-written from source/docs. Prompt v2 uses up to twelve named frames and three marked source snippets; allocator keys use four frames. Adaptive rechecks receive quantised sampled byte shares; static model never rechecks. Live sampling is 1/64 with counters merged every 4,096 successes. Replay retains the live instrumentation. Each model policy has a 400-answer budget shared with coverage fills; reused native two-class answers still consume slots. Legacy three-class caches are excluded.

Synthetic wrapper names are protected from compiler folding, and TTL selection cannot split the mixed allocation into separate PCs. The earlier partial run with folded identities is archived and excluded. Historical three-class tables remain in [the previous report](results/pass5/prior/RESULTS-before-two-class.md).

Execution details, validated hashes and recovery instructions are in [CODEX-REPORT.md](CODEX-REPORT.md). Pass 6 will replace these headline tables after the new instrument, sensitivity, fragmentation matrix and regression matrix are validated.
