#!/usr/bin/env python3
"""Prior-trace oracle: majority of requested bytes, not allocation count."""
import argparse
from common import sites, oracle, write_table

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('trace'); p.add_argument('-o', '--output', required=True)
    p.add_argument('--short-bytes',type=int,default=None)
    a = p.parse_args()
    write_table(a.output, ((s['key'], oracle(s,a.short_bytes)) for s in sites(a.trace)))
    print('Oracle: byte-majority site labels from a prior trace; not an RSS bound.')
if __name__ == '__main__': main()
