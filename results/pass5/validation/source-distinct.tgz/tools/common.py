"""Shared trace/table format; no third-party Python dependencies."""
import json
from pathlib import Path
CLASSES = ('short', 'long')

def sites(path):
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]

def class_bytes(site, short_bytes=None):
    if len(site['class_bytes']) != 2:
        raise ValueError('Legacy three-class trace: keep archived; retrace for two-class results')
    threshold = site.get('short_bytes', 1048576) if short_bytes is None else short_bytes
    if threshold <= 0: raise ValueError('short_bytes must be positive')
    if threshold == site.get('short_bytes', 1048576): return site['class_bytes']
    if threshold & (threshold-1):
        raise ValueError('Retrace for a non-power-of-two threshold; histogram is insufficient')
    short = sum(site['lifetime_histogram_bytes'][:threshold.bit_length()])
    return [short, site['bytes']-short]

def oracle(site, short_bytes=None):
    weights = class_bytes(site, short_bytes)
    return 0 if weights[0] > weights[1] else 1

def write_table(path, entries):
    entries = list(entries)
    if any(cls not in (0, 1) for _, cls in entries): raise ValueError('class must be 0 or 1')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(f'{key} {cls}\n' for key, cls in sorted(entries)))
